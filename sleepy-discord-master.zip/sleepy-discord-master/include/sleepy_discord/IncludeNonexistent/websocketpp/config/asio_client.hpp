#pragma once
#define NONEXISTENT_WEBSOCKETPP