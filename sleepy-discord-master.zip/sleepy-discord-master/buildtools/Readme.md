# Building Sleepy Discord

In this folder you'll find build tools for building Sleepy Discord

# Makefile.3ds

This is for building the library for the 3ds. You may need devkitpro for this.

To compile using this file run the following command:
```
make -f Makefile.3ds
```

# Makefile.linux

This is for building the library for linux.

To compile, use the following command:
```
make -f Makefile.linux
```